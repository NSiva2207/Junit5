package com.example.juJunitMockito.mockito;

import com.example.juJunitMockito.Repository.TodoRepository;
import com.example.juJunitMockito.service.TodoService;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.*;


import java.util.Arrays;
import java.util.List;

@RunWith(PowerMockRunner.class)
public class TodoImplStudTest {

   /* @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();*/

    @Mock
    TodoRepository todoServiceMock;

    @InjectMocks
    TodoService todoService;

    @Captor
    ArgumentCaptor<String> argumentCaptor;

    @Test
    public void testRetrieveTodosRelatedToSpring(){

        List<String> todos = Arrays.asList("spring mockito","JUnit spring", "non");
        given(todoServiceMock.todo("dummy")).willReturn(todos);


        List<String> filteredTodos = todoService.retrieveTodosRelatedToSpring("dummy");
        assertThat(filteredTodos.size(),is(2));


        todoService.deleteTodos("dummy");
        //verify(todoServiceMock).deleteTodo("non");
        then(todoServiceMock).should().deleteTodo(argumentCaptor.capture());
        assertThat(argumentCaptor.getValue(),is("non"));
    }
}

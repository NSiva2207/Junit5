package com.example.juJunitMockito.Repository;

import java.util.Arrays;
import java.util.List;

public class TodoRepositoryStubs implements TodoRepository{
    @Override
    public List<String> todo(String user) {
        return Arrays.asList("spring mockito","JUnit spring");
    }

    @Override
    public void deleteTodo(String user) {

    }
}

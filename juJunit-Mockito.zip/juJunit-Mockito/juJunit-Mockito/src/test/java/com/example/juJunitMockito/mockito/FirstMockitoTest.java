package com.example.juJunitMockito.mockito;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FirstMockitoTest {
    @Test
    public void test(){
        assertTrue(true);
    }
}

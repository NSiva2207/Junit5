package com.example.juJunitMockito.mockito;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

public class HamcrestMatchersTest {

    @Test
    public void test(){
        List<Integer> list = Arrays.asList(14,54,2,63);

        assertThat(list,hasSize(4));

    }
}

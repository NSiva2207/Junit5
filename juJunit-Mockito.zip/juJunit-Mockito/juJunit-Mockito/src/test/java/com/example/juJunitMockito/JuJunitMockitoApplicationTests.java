package com.example.juJunitMockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuJunitMockitoApplicationTests {

	@Test
	void contextLoads() {
	}

}

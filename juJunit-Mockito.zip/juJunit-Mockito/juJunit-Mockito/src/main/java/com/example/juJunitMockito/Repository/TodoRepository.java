package com.example.juJunitMockito.Repository;

import org.springframework.stereotype.Repository;

import java.util.List;


public interface TodoRepository {
    List<String> todo(String user);

    void deleteTodo(String user);
}

package com.example.juJunitMockito.service;

import com.example.juJunitMockito.Repository.TodoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
public class TodoService {
    private TodoRepository repository;

    public List<String> retrieveTodosRelatedToSpring(String user){
        List<String> filteredTodos = new ArrayList<>();
        List<String> todos = repository.todo(user);
        for(String todo : todos){
            if(todo.contains("spring")){
                filteredTodos.add(todo);
            }
        }
        return filteredTodos;
    }

    public void deleteTodos(String user){
        List<String> todos = repository.todo(user);
        for(String todo : todos){
            if(!todo.contains("spring")){
                repository.deleteTodo(todo);
            }
        }
    }
}
